package djf;

import java.util.Scanner;
import java.text.MessageFormat;



public class Personenregistrierung {



    private static Object begruessung;
    private static Scanner scan;





    public static void main(String[] args ) {

        System.out.println("---------------------------------------------------------------------------");
        System.out.println("Willkommen bei der Personenregistrierungsapp          v.1.0");
        System.out.println("---------------------------------------------------------------------------");
        System.out.println("");
        System.out.println("---------------------------------------------------------------------------");
        System.out.println("Bitte geben Sie die gewünschte Funktion ein:");
        System.out.println("Neue Person registrieren                  --> Drücken Sie Taste `1`");
        System.out.println("Alle vorhandenen Personen anzeigen        --> Drücken Sie Taste `2`");
        System.out.println("Eine Person löschen                       --> Drücken Sie Taste `3`");
        System.out.println("Details einer Person anzeigen             --> Drücken Sie Taste `4`");
        System.out.println("Personenregistrierung schliessen          --> Drücken Sie Taste `5`");
        System.out.println("---------------------------------------------------------------------------");

        inputPerson();



    }


    public static void inputPerson() {

        int i;

        Scanner benutzerEingabe = new Scanner(System.in);

        i = benutzerEingabe.nextInt();
        benutzerEingabe.close();

        switch (i) {
            case 1:
                personregistry();
                break;
            case 2:
                personenspeicher();
                break;
            case 3:
                persondeleted();
                break;
            case 4:
                personendetail();
                break;
            case 5:
                personenfinish();
                break;
            default:
                System.err.println("Bitte geben Sie eine Zahl zwischen 1 und 5 an!!");
        }

    }


    public static void personregistry() {

        Scanner benutzerEingabe = new Scanner(System.in);


        String firstName;
        String lastName;
        int age;
        boolean hasItsOwnHousehold;
        String street;
        String city;
        int PLZ;

        System.out.println("Bitte geben Sie ihren Namen ein:");
        benutzerEingabe.nextLine();


    }

    public static void personenspeicher() {

        System.out.println("Alle vorhandenen Personen anzeigen:");
        System.out.println("");

    }



    public static void persondeleted() {

        System.out.println("Eine Person löschen:");
        System.out.println("");

    }




    public static void personendetail() {

        System.out.println("Details einer Person anzeigen:");
        System.out.println("");

    }



    public static void personenfinish() {

        System.out.println("Personenregistrierung schliessen:");
        System.out.println("");

    }



}



