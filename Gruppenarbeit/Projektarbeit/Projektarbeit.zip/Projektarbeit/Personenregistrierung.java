public class Personenregistrierung {

    public static void main( String[] args );
    }
}

}
